##Required Features##    are added
1)  Modified the bubble movement to incorporate vertical motion such that the bubbles travel in a parabolic path. When the ball hits the horizontal ground, it bounce off the ground.
2)  Introduced  collision between the bubble and the bullet; the bubble disappears after a bullet hits it. After a collision,  bullet disappear .
3)  Introduced  collision between the bubble and the shooter; the shooter is dead if a bubble touches it.


Additional Features
1) Used bubbles of different sizes. When a bullet hits the larger bubble, it splits into smaller bubbles (half the radius of the original larger bubble) and move in horizontally opposite directions.
2)Added score, time and a health counter. The score increases whenever bullet hits a bubble. The game gets over when�we run out of time (measured in seconds) or if we run out of health (whenever the bubble hits the shooter, the health reduces by 1).


Extra Feature
* Game gets finished when all bubbles are destroyed.
*Game shows SCORE after game finishes.
*The bubble disappers when it collides with shooter.
*The shooter has different color with diffrent health.



Link to videos
1) WHEN ALL BUBBLES ARE SHOT .   | YOU WIN |  SCORE: 5/5 .     
     LINK :  https://drive.google.com/file/d/1nJWV0IeqgRtWwcjWQaz23zUJLOS4B2QP/view?usp=sharing
   
2) YOU LOSE THE GAME WHEN YOU RUN OUT OF HEALTHS AND SHOOTER COLOR CHANGES AS SHOOTER LOSSES HEALTH BY 1 . THE HEATH IS UPDATED .
    LINK : https://drive.google.com/file/d/1grekCFoASUhTtJe33ak3xmd1oHxG8JBM/view?usp=sharing

3)WHEN YOU RUN OUT OF TIME  YOU LOSE AND GAME ENDS.  TIMER OF 35 SECONDS IS ADDED.
   LINK: https://drive.google.com/file/d/16toDDnoT_dvwwxZfTygrlISXQ_J7VoNu/view?usp=sharing

4)When All bubbles are destroyed  Game finish and SCORE is displayed.
  LINK: https://drive.google.com/file/d/1OJrl-we5MA864oyXNLxOOEGwgdyGYTVZ/view?usp=sharing



